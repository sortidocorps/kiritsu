# tailwindcss-navbar
a simple responsive navbar for tailwind
